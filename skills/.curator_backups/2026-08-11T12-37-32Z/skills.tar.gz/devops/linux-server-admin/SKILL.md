---
name: linux-server-admin
description: "Use for Linux server tasks: USB mount, fstab, UFW, sudoers."
---

# Linux Server Administration

Non-trivial patterns for server administration on Ubuntu/Debian — USB auto-mount, firewall rules, restricted sudoers, Tailscale access. For Hermes-specific administration (backup, config, memory providers), use `hermes-administration`.

## Triggers

- USB flash drive / external storage mount
- fstab configuration, systemd automount
- Firewall (UFW) rules
- sudoers / NOPASSWD setup
- Tailscale remote access
- Server diagnostics (temperature, load, RAM)

## USB Auto-Mount Pattern (fstab + systemd)

Goal: USB drive auto-mounts when plugged in, survives reboot, and never causes boot failure when missing.

### Step 1: Identify UUID

```bash
lsblk -f /dev/sdX
# or: blkid /dev/sdX1
```

### Step 2: fstab entry

```
UUID=XXXX-YYYY /mnt/mountpoint fs_type nofail,noatime,nosuid,nodev,umask=000,x-systemd.automount,x-systemd.idle-timeout=600,x-systemd.device-timeout=5 0 0
```

Key options:
- `nofail` — boot continues if drive missing (CRITICAL)
- `x-systemd.automount` — mount on first access, not at boot
- `x-systemd.idle-timeout=600` — auto-unmount after 10 min idle (safe to unplug)
- `x-systemd.device-timeout=5` — give up fast if device missing
- `umask=000` — world read/write (exFAT/vFAT don't support Unix perms)
- `nosuid,nodev` — security hardening for removable media
- `noatime` — reduce writes on flash drives

### Step 3: After fstab edit

```bash
sudo systemctl daemon-reload
# Start the automount unit (systemd fstab-generator creates these)
sudo systemctl start 'mnt-mountpoint.automount'
```

### Pitfalls

### Pitfalls

- **Hyphen in mount path**: systemd escapes `-` to `\\x2d` in unit names. Use `systemctl list-units 'mnt*'` to find real unit names, then start with escaped form: `systemctl start 'mnt-usb\\x2dnvme.automount'`. If glob/escaped forms fail, use path-based start: `systemctl start /mnt/usb-nvme`.
- **After fstab changes on a running system**: automount units are created but NOT auto-started. Manual `systemctl daemon-reload` then `systemctl start /mnt/<mount>` required. On reboot they activate automatically.
- **exFAT**: may need `apt install exfat-fuse exfatprogs`
- **polkit blocking**: `udisksctl mount` may fail without desktop session. Use fstab+sudo instead.
- **idempotent**: always `grep` before appending to `/etc/fstab` to avoid duplicates

## Remote Access + UFW (Tailscale)

When services listening on `0.0.0.0` are unreachable via Tailscale from another device, but `curl` works locally — UFW default-deny is the culprit.

```bash
sudo ufw allow in on tailscale0
```

This opens traffic from Tailscale-authenticated devices only — no public exposure.
**User preference**: Tailscale direct IP (`http://100.92.237.45:PORT`), not Cloudflare tunnel DNS.

## OmniRoute Diagnostics

For auth failures or routing issues: query `~/.omniroute/storage.sqlite` directly. See `references/omniroute-schema.md` for schema and queries.

## Restricted sudoers Rule

Allow specific commands without password, block everything else:

```bash
echo 'username ALL=(ALL) NOPASSWD: /usr/bin/mount, /usr/bin/umount, /usr/bin/mkdir' | sudo tee /etc/sudoers.d/hermes-mount && sudo chmod 440 /etc/sudoers.d/hermes-mount
```

- File must be `440` perms or sudo ignores it
- Use `/etc/sudoers.d/` subdirectory, never edit `/etc/sudoers` directly
- Verify: `sudo -n mount` → OK; `sudo -n rm` → "password required" (blocked)

## Tailscale + UFW Remote Access

```bash
# Allow all Tailscale traffic through firewall
sudo ufw allow in on tailscale0
```

- Access via Tailscale IP (e.g. `http://100.92.237.45:9119`) or MagicDNS (`http://n8nserver.tailf595e8.ts.net:9119`)
- Only devices in your tailnet can reach the server — not public internet

## Server Diagnostics

```bash
# Temperature
sensors | grep -iE 'temp|tctl'
# Fallback: cat /sys/class/thermal/thermal_zone*/{type,temp}

# Load & RAM
uptime
free -h

# Top processes
ps aux --sort=-%cpu | head -8
```

## OmniRoute Model Query

OmniRoute stores configuration in SQLite at `~/.omniroute/storage.sqlite`. See `references/omniroute-schema.md` for table structure and query patterns.
